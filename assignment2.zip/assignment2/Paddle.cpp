#include "Paddle.h"

#include <ostream>

namespace arkanoid
{
	Paddle::Paddle()
	{
	}
	Paddle::Paddle(Point p, int32_t w, int32_t h, int32_t v)
	{
		lowright.x = p.x + w;
		lowright.y = p.y + h;
		upleft.x = p.x;
		upleft.y = p.y;
		vel = v;
	}
struct Point Paddle::getLowerRight() const
	{
	return lowright;
	}
struct Point Paddle::getUpperLeft() const
	{
	return upleft;
	}
int32_t Paddle::getVelocity() const
	{
	return vel;
	}
void Paddle::setLowerRight(struct Point p)
{
	lowright.x = p.x;
	lowright.y = p.y;
}
void Paddle::setUpperLeft(struct Point p)
{
	upleft.x = p.x;
	upleft.y = p.y;
}
void Paddle::setVelocity(int32_t v)
{
	vel = v;
}
void Paddle::movePaddle()
{
	upleft.x += vel;
	lowright.x += vel;
}
std::ostream& operator<<(std::ostream& os, const Paddle& paddle) {
	os << "Paddle { " << paddle.getUpperLeft() << ", " << paddle.getLowerRight() << ", velocity = " << paddle.getVelocity() << " }"; 
	return os;
}

}
